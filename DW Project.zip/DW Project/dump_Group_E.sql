SHOW TABLES;

SELECT * FROM demographic;

SELECT * FROM languages;
SELECT * FROM certifications;
SELECT * FROM connections;
SELECT * FROM education;
SELECT * FROM experiences;
SELECT * FROM languages;
SELECT * FROM patent;
SELECT * FROM projects;
SELECT * FROM publications;
SELECT * FROM volunteer;